import React from "react";
import "./Kits.css";
import ma

const Kits = () => {
    return (
        <div>
            <h1>Joga Bonito Retro</h1>
            
            
        </div>
    );
};

export default Kits;